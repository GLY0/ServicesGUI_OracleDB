
package conexion;

import clases.Usuario;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author miche
 */
public class Conectar {
   
    public static Connection getConnectiion() {
        
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection cone = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "grupoG", "g123");
            return cone;
        } catch (Exception e) {}
        return null;
    }

    public int Inicio(String usuario, String clave) {

        int valor = 0;
        try {
            Connection cone = getConnectiion();
            Statement sta = cone.createStatement();
            ResultSet rs = sta.executeQuery("Select * from usuario Where nombre = '" + usuario + "' and clave = '" + clave + "'");

            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "BIENVENIDOS SU SISTEMA ", "INFORMACION", JOptionPane.INFORMATION_MESSAGE);
                valor = 1;
            } else {
                JOptionPane.showMessageDialog(null, "Ingresa usuario y contraseña", "ERROR", JOptionPane.ERROR_MESSAGE);

                valor = 0;

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "error" + e.getMessage(), e.getMessage(), JOptionPane.ERROR_MESSAGE);

        }

        return valor;
    }
      public ArrayList<Usuario> ListaUsuario() {
        ArrayList<Usuario> us = new ArrayList();
        try {
            //conectamos
             Connection cone = getConnectiion();
            Statement st = cone.createStatement();
            //se indica los campos y la tabla para mostrar
            ResultSet resul = st.executeQuery("  SELECT cedula,nombre,apellido,fecha,rol,clave"
                    + "    FROM usuario ORDER BY 1  ");
            while (resul.next()) {
                Usuario u = new Usuario();
                u.setCedula(resul.getInt("cedula"));
                u.setNombre(resul.getString("nombre"));
                u.setApellido(resul.getString("apellido"));
                u.setFecha(resul.getString("fecha"));
                u.setRol(resul.getString("rol"));
                u.setClave(resul.getString("clave"));
                us.add(u);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            System.out.println("HA OCURRIDO UN ERROR");
        }
        return us;
    }

    public void InsertarRegistroUsuario(Usuario user) {
        try {
            //conectamos
             Connection cone = getConnectiion();
            //se llama la tabla con sus atributos
            PreparedStatement pst = cone.prepareStatement("INSERT INTO usuario (cedula,nombre,apellido,fecha,rol,clave)"
                    + "     VALUES(?,?,?,?,?,?)");
            pst.setInt(1, user.getCedula());
            pst.setString(2, user.getNombre());
            pst.setString(3, user.getApellido());
            pst.setString(4, user.getFecha());
            pst.setString(5, user.getRol());
            pst.setString(6, user.getClave());
            pst.executeQuery();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            System.out.println("Error en los datos");
        }
    }
}

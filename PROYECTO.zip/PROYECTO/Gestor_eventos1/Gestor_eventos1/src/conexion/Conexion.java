package conexion;
import clases.Evento;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
public class Conexion {
    public static Connection getConnection() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection cone = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","ADMINISTRADOR","ADMINISTRADOR");
            return cone;
        } catch (Exception e) {
        }return null;
    }
    public ArrayList<Evento> ListaEvento() {
        ArrayList<Evento> ev = new ArrayList();
        try {
            //conectamos
            Connection cone = getConnection();
            Statement st = cone.createStatement();
            //se indica los campos y la tabla para mostrar
            ResultSet resul = st.executeQuery("  SELECT  tipoEvento,nombre, apellido,cedula,invitados,fecha,horario,lugar,fotografia,cathering,decoracion"  
                    + "   FROM evento ORDER BY 1  ");
            while (resul.next()) {
                Evento e = new Evento();
                e.setTipoEvento(resul.getString("tipoEvento"));
                e.setNombre(resul.getString("nombre"));
                e.setApellido(resul.getString("apellido"));
                e.setCedula(resul.getString("cedula"));
                e.setFecha(resul.getString("fecha"));
                e.setInvitados(resul.getInt("invitados"));
                e.setHorario(resul.getString("horario"));
                e.setLugar(resul.getString("lugar"));
                e.setFotografia(resul.getString("fotografia"));
                e.setCathering(resul.getString("cathering"));
                e.setDecoracion(resul.getString("decoracion"));
                ev.add(e);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            System.out.println("HA OCURRIDO UN ERROR");
        }
        return ev;
    }
    public void InsertarRegistroEvento(Evento evento) {
        try {
            //conectamos
            Connection cone = getConnection();
            //se llama la tabla con sus atributos
            String Datos = "INSERT INTO evento(tipoEvento,nombre, apellido,cedula,invitados,fecha,horario,lugar,fotografia,cathering,decoracion)VALUES(?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement pst = cone.prepareStatement(Datos);
            pst.setString(1, evento.getTipoEvento());
            pst.setString(2, evento.getNombre());
            pst.setString(3, evento.getApellido());
            pst.setString(4, evento.getCedula());
            pst.setInt(5, evento.getInvitados());
            pst.setString(6, evento.getFecha());
            pst.setString(7, evento.getHorario());
            pst.setString(8, evento.getLugar());
            pst.setString(9, evento.getFotografia());
            pst.setString(10, evento.getCathering());
            pst.setString(11, evento.getDecoracion());
            pst.execute();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            System.out.println("Error en los datos");
        }
    }
}
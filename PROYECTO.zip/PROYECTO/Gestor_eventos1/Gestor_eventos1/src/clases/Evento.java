package clases;

public class Evento {
    private int IDevento;
    public int Invitados;
    public String tipoEvento,nombre,apellido,cedula,fecha,horario,lugar,fotografia,cathering,decoracion;    
    public Evento(){
        
    }
    public Evento(int IDevento, String tipoEvento, String nombre,String apellido,int Invitados,String cedula,String fecha,String horario,String lugar,String  fotografia,String  cathering,String decoracion) {
        this.IDevento=IDevento;
        this.tipoEvento = tipoEvento;
        this.nombre = nombre;
        this.apellido = apellido;
        this.cedula = cedula;
        this.Invitados= Invitados;
        this.fecha = fecha;
        this.horario = horario;
        this.lugar=lugar;
        this.fotografia=fotografia;
        this.cathering=cathering;
        this.decoracion=decoracion;
    }

    public int getIDevento() {
        return IDevento;
    }

    public int getInvitados() {
        return Invitados;
    }

    public String getTipoEvento() {
        return tipoEvento;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getCedula() {
        return cedula;
    }

    public String getFecha() {
        return fecha;
    }

    public String getHorario() {
        return horario;
    }

    public String getLugar() {
        return lugar;
    }

    public String  getFotografia() {
        return fotografia;
    }

    public String  getCathering() {
        return cathering;
    }

    public String getDecoracion() {
        return decoracion;
    }

    public void setIDevento(int IDevento) {
        this.IDevento = IDevento;
    }

    public void setInvitados(int Invitados) {
        this.Invitados = Invitados;
    }

    public void setTipoEvento(String tipoEvento) {
        this.tipoEvento = tipoEvento;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public void setFotografia(String  fotografia) {
        this.fotografia = fotografia;
    }

    public void setCathering(String  cathering) {
        this.cathering = cathering;
    }

    public void setDecoracion(String  decoracion) {
        this.decoracion = decoracion;
    }

    @Override
    public String toString() {
        return "Evento{" + "IDevento=" + IDevento + ", Invitados=" + Invitados + ", tipoEvento=" + tipoEvento + ", nombre=" + nombre + ", apellido=" + apellido + ", cedula=" + cedula + ", fecha=" + fecha + ", horario=" + horario + ", lugar=" + lugar + ", fotografia=" + fotografia + ", cathering=" + cathering + ", decoracion=" + decoracion + '}';
    }
    
}
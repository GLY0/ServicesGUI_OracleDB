package Vistas;

import clases.Evento;
import conexion.Conexion;
import java.awt.event.KeyEvent;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Reserva_Evento extends javax.swing.JFrame {
    Conexion conec = new Conexion();    
    public Reserva_Evento() {
        initComponents();
    }  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        lblTipoEvento = new javax.swing.JLabel();
        txtTipoEvento = new javax.swing.JTextField();
        lblNombre = new javax.swing.JLabel();
        lblFecha = new javax.swing.JLabel();
        lblCedula = new javax.swing.JLabel();
        lblInvitados = new javax.swing.JLabel();
        txtApellido = new javax.swing.JTextField();
        txtCedula = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        lblLugar = new javax.swing.JLabel();
        cmbLugar = new javax.swing.JComboBox<>();
        lblApellido = new javax.swing.JLabel();
        lblHorario = new javax.swing.JLabel();
        cmbHorario = new javax.swing.JComboBox<>();
        rbCatsi = new javax.swing.JRadioButton();
        rbCatno = new javax.swing.JRadioButton();
        lblCatering = new javax.swing.JLabel();
        lblFotografia = new javax.swing.JLabel();
        lblDecoracion = new javax.swing.JLabel();
        rbDecosi = new javax.swing.JRadioButton();
        rbFotsi = new javax.swing.JRadioButton();
        rbFotno = new javax.swing.JRadioButton();
        rbDecono = new javax.swing.JRadioButton();
        txtNroInvitados = new javax.swing.JTextField();
        btnReservar = new javax.swing.JButton();
        jsFecha = new javax.swing.JSpinner();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(239, 239, 246));

        jPanel3.setBackground(new java.awt.Color(239, 239, 246));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        jPanel3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jLabel1.setFont(new java.awt.Font("Batang", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 153, 255));
        jLabel1.setText("EVENTOS SOFTSI ");

        jLabel4.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 51, 51));
        jLabel4.setText("ORGANIZACION DE EVENTOS SOCIALES");

        jLabel6.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(51, 51, 51));
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/user.png"))); // NOI18N
        jLabel6.setText("MI CUENTA");
        jLabel6.setToolTipText("");
        jLabel6.setMaximumSize(new java.awt.Dimension(48, 48));
        jLabel6.setMinimumSize(new java.awt.Dimension(48, 48));
        jLabel6.setPreferredSize(new java.awt.Dimension(48, 48));

        jLabel18.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(51, 51, 51));
        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/menu.png"))); // NOI18N
        jLabel18.setText("MENU");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel18)
                .addGap(18, 18, 18)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel18)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(239, 239, 246));

        jLabel3.setFont(new java.awt.Font("Cambria", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 51, 51));
        jLabel3.setText("RESERVA DE EVENTO");

        lblTipoEvento.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lblTipoEvento.setForeground(new java.awt.Color(51, 51, 51));
        lblTipoEvento.setText("Tipo de Evento: ");

        txtTipoEvento.setBackground(new java.awt.Color(204, 204, 204));
        txtTipoEvento.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTipoEventoKeyTyped(evt);
            }
        });

        lblNombre.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lblNombre.setForeground(new java.awt.Color(51, 51, 51));
        lblNombre.setText("Nombre: ");

        lblFecha.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lblFecha.setForeground(new java.awt.Color(51, 51, 51));
        lblFecha.setText("Fecha:");

        lblCedula.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lblCedula.setForeground(new java.awt.Color(51, 51, 51));
        lblCedula.setText("Nro de Cedula:");

        lblInvitados.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lblInvitados.setForeground(new java.awt.Color(51, 51, 51));
        lblInvitados.setText("Nro de Invitados:");

        txtApellido.setBackground(new java.awt.Color(204, 204, 204));
        txtApellido.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtApellidoKeyTyped(evt);
            }
        });

        txtCedula.setBackground(new java.awt.Color(204, 204, 204));
        txtCedula.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCedulaKeyTyped(evt);
            }
        });

        txtNombre.setBackground(new java.awt.Color(204, 204, 204));
        txtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNombreKeyTyped(evt);
            }
        });

        lblLugar.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lblLugar.setForeground(new java.awt.Color(51, 51, 51));
        lblLugar.setText("Lugar:");

        cmbLugar.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sauces 1", "Alborada", "Perimetral" }));

        lblApellido.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lblApellido.setForeground(new java.awt.Color(51, 51, 51));
        lblApellido.setText("Apellido");

        lblHorario.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lblHorario.setForeground(new java.awt.Color(51, 51, 51));
        lblHorario.setText("Horario");

        cmbHorario.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Matutino", "Vespertino", "Nocturno" }));

        buttonGroup1.add(rbCatsi);
        rbCatsi.setForeground(new java.awt.Color(51, 51, 51));
        rbCatsi.setText("Si");
        rbCatsi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbCatsiActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbCatno);
        rbCatno.setForeground(new java.awt.Color(51, 51, 51));
        rbCatno.setText("No");
        rbCatno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbCatnoActionPerformed(evt);
            }
        });

        lblCatering.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lblCatering.setForeground(new java.awt.Color(51, 51, 51));
        lblCatering.setText("¿Incluye Catering ?");

        lblFotografia.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lblFotografia.setForeground(new java.awt.Color(51, 51, 51));
        lblFotografia.setText("¿Incluye Fotografia ?");

        lblDecoracion.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lblDecoracion.setForeground(new java.awt.Color(51, 51, 51));
        lblDecoracion.setText("¿Incluye Decoracion ?");

        buttonGroup3.add(rbDecosi);
        rbDecosi.setForeground(new java.awt.Color(51, 51, 51));
        rbDecosi.setText("Si");
        rbDecosi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbDecosiActionPerformed(evt);
            }
        });

        buttonGroup2.add(rbFotsi);
        rbFotsi.setForeground(new java.awt.Color(51, 51, 51));
        rbFotsi.setText("Si");
        rbFotsi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbFotsiActionPerformed(evt);
            }
        });

        buttonGroup2.add(rbFotno);
        rbFotno.setForeground(new java.awt.Color(51, 51, 51));
        rbFotno.setText("No");
        rbFotno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbFotnoActionPerformed(evt);
            }
        });

        buttonGroup3.add(rbDecono);
        rbDecono.setForeground(new java.awt.Color(51, 51, 51));
        rbDecono.setText("No");
        rbDecono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbDeconoActionPerformed(evt);
            }
        });

        txtNroInvitados.setBackground(new java.awt.Color(204, 204, 204));
        txtNroInvitados.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNroInvitadosKeyTyped(evt);
            }
        });

        btnReservar.setText("RESERVAR");
        btnReservar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReservarActionPerformed(evt);
            }
        });

        jsFecha.setModel(new javax.swing.SpinnerDateModel());
        jsFecha.setEditor(new javax.swing.JSpinner.DateEditor(jsFecha, "yyyy/MM/dd"));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(lblTipoEvento)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblFecha))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblNombre)
                            .addComponent(lblApellido)
                            .addComponent(lblCedula)
                            .addComponent(lblInvitados))
                        .addGap(21, 21, 21)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtTipoEvento)
                            .addComponent(txtNombre, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE)
                            .addComponent(txtApellido, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE)
                            .addComponent(txtNroInvitados)
                            .addComponent(txtCedula))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 68, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblFotografia, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblDecoracion, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblHorario, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblLugar, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblCatering, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addGap(48, 48, 48)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cmbLugar, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmbHorario, 0, 151, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(rbCatsi)
                        .addGap(18, 18, 18)
                        .addComponent(rbCatno))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(rbFotsi)
                        .addGap(18, 18, 18)
                        .addComponent(rbFotno))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(rbDecosi)
                        .addGap(18, 18, 18)
                        .addComponent(rbDecono))
                    .addComponent(jsFecha))
                .addGap(28, 28, 28))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(290, 290, 290)
                .addComponent(btnReservar, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(255, 255, 255))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel3)
                .addGap(39, 39, 39)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTipoEvento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTipoEvento)
                    .addComponent(lblFecha)
                    .addComponent(jsFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblNombre)
                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblHorario)
                        .addComponent(cmbHorario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cmbLugar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblLugar)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblApellido))))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(0, 5, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblCatering)
                            .addComponent(rbCatno)
                            .addComponent(rbCatsi))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblFotografia)
                            .addComponent(rbFotsi)
                            .addComponent(rbFotno))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblDecoracion)
                            .addComponent(rbDecosi)
                            .addComponent(rbDecono))
                        .addGap(34, 34, 34))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addComponent(txtCedula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addComponent(lblCedula)))
                        .addGap(8, 8, 8)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtNroInvitados, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblInvitados))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(btnReservar)
                .addGap(26, 26, 26))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void rbCatsiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbCatsiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbCatsiActionPerformed

    private void rbCatnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbCatnoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbCatnoActionPerformed

    private void rbDecosiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbDecosiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbDecosiActionPerformed

    private void rbFotsiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbFotsiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbFotsiActionPerformed

    private void rbFotnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbFotnoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbFotnoActionPerformed

    private void rbDeconoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbDeconoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbDeconoActionPerformed

    private void btnReservarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReservarActionPerformed
        String TipoEvento = txtTipoEvento.getText();
        String cedula = txtCedula.getText();
        String nombre = txtNombre.getText();
        String apellido = txtApellido.getText();
        String NroInvitados = txtNroInvitados.getText();       
        String cathering = " ";
        if(rbCatsi.isSelected()==true){ 
            cathering = "si";
        }else if(rbCatno.isSelected()==true) {
            cathering = "no";
        }
        String fotografia = " ";
        if(rbFotsi.isSelected()==true){
            fotografia = "Si";
        }else if(rbFotno.isSelected()==true) {
            fotografia = "No";
        }
        String decoracion = " ";
        if(rbDecosi.isSelected()==true){
            decoracion = "Si";
        }else if(rbDecono.isSelected()==true){
            decoracion = "No";
        }        
        String mensajeError = "";
        Boolean hayErrores = false;
        if (cedula.equals("")) {
            mensajeError += "Ingrese su cedula\n";
            hayErrores = true;
        }
        if (nombre.equals("")) {
            mensajeError += "Ingrese su nombre\n";
            hayErrores = true;
        }
        if (apellido.equals("")) {
            mensajeError += "Ingrese su apellido\n";
            hayErrores = true;
        }
        if (hayErrores) {
            JOptionPane.showMessageDialog(this, mensajeError);
            return;
        }
        Gestor_eventos gestion = new Gestor_eventos();
        Evento e = new Evento();
        e.setTipoEvento(TipoEvento);
        e.setNombre(nombre);
        e.setApellido(apellido);
        e.setCedula(cedula);
        e.setInvitados(Integer.parseInt(NroInvitados));        
        SimpleDateFormat formater = new SimpleDateFormat("yyyy/MM/dd");
        String spinnerValue = formater.format(jsFecha.getValue());
        e.setFecha(spinnerValue);        
        e.setHorario(cmbHorario.getSelectedItem().toString());
        e.setLugar(cmbLugar.getSelectedItem().toString());
        e.setCathering(cathering);
        e.setFotografia(fotografia);
        e.setDecoracion(decoracion);        
        conec.InsertarRegistroEvento(e);
        if("Cumpleaños".equalsIgnoreCase(e.getTipoEvento())){
            gestion.limpiarDatosCumpleanio();
            gestion.listarTablaCumpleanio();
        }else if("Boda".equalsIgnoreCase(e.getTipoEvento())){
            gestion.limpiarDatosBoda();
            gestion.listarTablaBoda();
        }else if("Graduacion".equalsIgnoreCase(e.getTipoEvento())){
            gestion.limpiarDatosGraduacion();
            gestion.listarTablaGraduacion();
        }
        JOptionPane.showMessageDialog(this, "Guardado correctamente", "INFORMACION", JOptionPane.INFORMATION_MESSAGE);  
    }//GEN-LAST:event_btnReservarActionPerformed

    private void txtTipoEventoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTipoEventoKeyTyped
        char t;
        t = evt.getKeyChar();
        if (!Character.isLetter(t)&&t!=KeyEvent.VK_SPACE&&t!=KeyEvent.VK_BACK_SPACE){
            evt.consume();
            getToolkit().beep();
            JOptionPane.showMessageDialog(this, "solo letras", "ALERTA", JOptionPane.WARNING_MESSAGE);
        }        
    }//GEN-LAST:event_txtTipoEventoKeyTyped

    private void txtNombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyTyped
       char t;
        t = evt.getKeyChar();
        if (!Character.isLetter(t)&&t!=KeyEvent.VK_SPACE&&t!=KeyEvent.VK_BACK_SPACE){
            evt.consume();
            getToolkit().beep();
       JOptionPane.showMessageDialog(this, "solo letras", "ALERTA", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_txtNombreKeyTyped

    private void txtApellidoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtApellidoKeyTyped
        char t = evt.getKeyChar();
        if (!Character.isLetter(t)&&t!=KeyEvent.VK_SPACE&&t!=KeyEvent.VK_BACK_SPACE){
            evt.consume();
            getToolkit().beep();
        JOptionPane.showMessageDialog(this, "solo letras", "ALERTA", JOptionPane.WARNING_MESSAGE);
        }     
    }//GEN-LAST:event_txtApellidoKeyTyped

    private void txtCedulaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCedulaKeyTyped
        char t = evt.getKeyChar();
        if (!Character.isDigit(t)&&t!=KeyEvent.VK_BACK_SPACE){
            evt.consume();
            getToolkit().beep();
        JOptionPane.showMessageDialog(this, "solo numeros", "ALERTA", JOptionPane.WARNING_MESSAGE);
        }
        boolean valido = true;
        if (txtCedula.getText().length() >= 10) {
            valido = false; 
        } 
        if (!valido) {
            evt.consume();
        JOptionPane.showMessageDialog(this, "Se esperan 10 digitos", "ALERTA", JOptionPane.WARNING_MESSAGE);     
        }                      
    }//GEN-LAST:event_txtCedulaKeyTyped

    private void txtNroInvitadosKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNroInvitadosKeyTyped
        char t;
        t = evt.getKeyChar();
        if (!Character.isDigit(t)&&t!=KeyEvent.VK_BACK_SPACE){
            evt.consume();
            getToolkit().beep();
       JOptionPane.showMessageDialog(this, "solo numeros", "ALERTA", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_txtNroInvitadosKeyTyped
                                                              
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {  
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Reserva_Evento().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnReservar;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.JComboBox<String> cmbHorario;
    private javax.swing.JComboBox<String> cmbLugar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JSpinner jsFecha;
    private javax.swing.JLabel lblApellido;
    private javax.swing.JLabel lblCatering;
    private javax.swing.JLabel lblCedula;
    private javax.swing.JLabel lblDecoracion;
    private javax.swing.JLabel lblFecha;
    private javax.swing.JLabel lblFotografia;
    private javax.swing.JLabel lblHorario;
    private javax.swing.JLabel lblInvitados;
    private javax.swing.JLabel lblLugar;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblTipoEvento;
    private javax.swing.JRadioButton rbCatno;
    private javax.swing.JRadioButton rbCatsi;
    private javax.swing.JRadioButton rbDecono;
    private javax.swing.JRadioButton rbDecosi;
    private javax.swing.JRadioButton rbFotno;
    private javax.swing.JRadioButton rbFotsi;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtCedula;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtNroInvitados;
    private javax.swing.JTextField txtTipoEvento;
    // End of variables declaration//GEN-END:variables
}

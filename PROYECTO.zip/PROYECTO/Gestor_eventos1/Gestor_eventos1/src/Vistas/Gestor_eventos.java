package Vistas;

import clases.Evento;
import conexion.Conexion;
import static conexion.Conexion.getConnection;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Gestor_eventos extends javax.swing.JFrame {
    PreparedStatement ps = null;
    Statement st = null;
    ResultSet rs = null;
    Conexion conec = new Conexion();
    ArrayList<Evento> evento;
    int cont = 0;  
    public Gestor_eventos() {
        initComponents();
        limpiarDatosCumpleanio();
        limpiarDatosBoda();
        limpiarDatosGraduacion();
        listarTablaCumpleanio();
        listarTablaGraduacion();
        listarTablaBoda();
    }
    public void listarTablaCumpleanio() {
        evento = conec.ListaEvento();
        for (Evento e : evento) {  
            if(e.getTipoEvento().equalsIgnoreCase("Cumpleaños")){
                DefaultTableModel modelo1 = (DefaultTableModel) GestorCumpleaños.getModel();
                modelo1.addRow(new Object[]{e.getCedula(), e.getHorario(),e.getLugar()
                    ,e.getCathering(), e.getFotografia(), e.getDecoracion()});           
            }
        }
    }
    public void listarTablaBoda() {
        evento = conec.ListaEvento();
        for (Evento e : evento) {  
            if(e.getTipoEvento().equalsIgnoreCase("Boda")){
                DefaultTableModel modelo2 = (DefaultTableModel) GestorBodas.getModel();
                modelo2.addRow(new Object[]{e.getCedula(), e.getHorario(),e.getLugar()
                        ,e.getCathering(), e.getFotografia(), e.getDecoracion()});
                }
        }
    }
    public void listarTablaGraduacion() {
        evento = conec.ListaEvento();
        for (Evento e : evento) { 
            if(e.getTipoEvento().equalsIgnoreCase("Graduacion")){
                DefaultTableModel modelo3 = (DefaultTableModel) GestorGraduacion.getModel();
                modelo3.addRow(new Object[]{e.getCedula(), e.getHorario(),e.getLugar()
                   ,e.getCathering(), e.getFotografia(), e.getDecoracion()});
                } 
        }
    }
    public void limpiarDatosCumpleanio() {
        DefaultTableModel modelo2 = (DefaultTableModel) GestorCumpleaños.getModel();
        for (cont = GestorCumpleaños.getRowCount() - 1; cont >= 0; cont--) {
            modelo2.removeRow(cont);
        }
    }
    public void limpiarDatosBoda() {
        DefaultTableModel modelo1 = (DefaultTableModel) GestorBodas.getModel();
        for (cont = GestorBodas.getRowCount() - 1; cont >= 0; cont--) {
            modelo1.removeRow(cont);
        }
    }
    public void limpiarDatosGraduacion() {
        DefaultTableModel modelo3 = (DefaultTableModel) GestorGraduacion.getModel();
        for (cont = GestorGraduacion.getRowCount() - 1; cont >= 0; cont--) {
            modelo3.removeRow(cont);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jDesktopPane1 = new javax.swing.JDesktopPane();
        Gestor = new javax.swing.JTabbedPane();
        jScrollPane8 = new javax.swing.JScrollPane();
        GestorBodas = new javax.swing.JTable();
        jScrollPane6 = new javax.swing.JScrollPane();
        GestorCumpleaños = new javax.swing.JTable();
        jScrollPane7 = new javax.swing.JScrollPane();
        GestorGraduacion = new javax.swing.JTable();
        jPanel6 = new javax.swing.JPanel();
        lblBuscar = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        btnEliminar = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel11 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(239, 239, 246));
        setBounds(new java.awt.Rectangle(0, 0, 0, 0));

        jPanel1.setBackground(new java.awt.Color(239, 239, 246));

        jPanel4.setBackground(new java.awt.Color(239, 239, 246));

        Gestor.setBackground(new java.awt.Color(204, 204, 204));
        Gestor.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        Gestor.setToolTipText("");
        Gestor.setAutoscrolls(true);
        Gestor.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        Gestor.setName("Gestor"); // NOI18N

        GestorBodas.setAutoCreateRowSorter(true);
        GestorBodas.setBackground(new java.awt.Color(204, 204, 204));
        GestorBodas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Cedula", "Horario", "Lugar", "Catering", "Fotografia", "Decoracion"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        GestorBodas.setColumnSelectionAllowed(true);
        GestorBodas.setSurrendersFocusOnKeystroke(true);
        jScrollPane8.setViewportView(GestorBodas);
        GestorBodas.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        if (GestorBodas.getColumnModel().getColumnCount() > 0) {
            GestorBodas.getColumnModel().getColumn(0).setResizable(false);
            GestorBodas.getColumnModel().getColumn(0).setPreferredWidth(200);
            GestorBodas.getColumnModel().getColumn(1).setPreferredWidth(20);
            GestorBodas.getColumnModel().getColumn(2).setResizable(false);
            GestorBodas.getColumnModel().getColumn(2).setPreferredWidth(200);
            GestorBodas.getColumnModel().getColumn(3).setResizable(false);
            GestorBodas.getColumnModel().getColumn(3).setPreferredWidth(10);
            GestorBodas.getColumnModel().getColumn(4).setResizable(false);
            GestorBodas.getColumnModel().getColumn(4).setPreferredWidth(10);
            GestorBodas.getColumnModel().getColumn(5).setResizable(false);
            GestorBodas.getColumnModel().getColumn(5).setPreferredWidth(10);
        }
        GestorBodas.getAccessibleContext().setAccessibleName("GestorBodas");
        GestorBodas.getAccessibleContext().setAccessibleParent(Gestor);

        Gestor.addTab("GESTOR DE BODAS", jScrollPane8);

        GestorCumpleaños.setBackground(new java.awt.Color(204, 204, 204));
        GestorCumpleaños.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Cedula", "Horario", "Lugar", "Catering", "Fotografia", "Decoracion"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        GestorCumpleaños.setColumnSelectionAllowed(true);
        GestorCumpleaños.setSurrendersFocusOnKeystroke(true);
        jScrollPane6.setViewportView(GestorCumpleaños);
        GestorCumpleaños.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        if (GestorCumpleaños.getColumnModel().getColumnCount() > 0) {
            GestorCumpleaños.getColumnModel().getColumn(0).setPreferredWidth(200);
            GestorCumpleaños.getColumnModel().getColumn(1).setPreferredWidth(20);
            GestorCumpleaños.getColumnModel().getColumn(2).setResizable(false);
            GestorCumpleaños.getColumnModel().getColumn(2).setPreferredWidth(200);
            GestorCumpleaños.getColumnModel().getColumn(3).setResizable(false);
            GestorCumpleaños.getColumnModel().getColumn(3).setPreferredWidth(10);
            GestorCumpleaños.getColumnModel().getColumn(4).setResizable(false);
            GestorCumpleaños.getColumnModel().getColumn(4).setPreferredWidth(10);
            GestorCumpleaños.getColumnModel().getColumn(5).setResizable(false);
            GestorCumpleaños.getColumnModel().getColumn(5).setPreferredWidth(10);
        }
        GestorCumpleaños.getAccessibleContext().setAccessibleName("GestorCumpleaños");
        GestorCumpleaños.getAccessibleContext().setAccessibleParent(Gestor);

        Gestor.addTab("GESTOR DE CUMPLEAÑOS", jScrollPane6);

        GestorGraduacion.setBackground(new java.awt.Color(204, 204, 204));
        GestorGraduacion.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Cedula", "Horario", "Lugar", "Catering", "Fotografia", "Decoracion"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        GestorGraduacion.setColumnSelectionAllowed(true);
        GestorGraduacion.setSurrendersFocusOnKeystroke(true);
        jScrollPane7.setViewportView(GestorGraduacion);
        GestorGraduacion.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        if (GestorGraduacion.getColumnModel().getColumnCount() > 0) {
            GestorGraduacion.getColumnModel().getColumn(0).setResizable(false);
            GestorGraduacion.getColumnModel().getColumn(0).setPreferredWidth(200);
            GestorGraduacion.getColumnModel().getColumn(1).setPreferredWidth(20);
            GestorGraduacion.getColumnModel().getColumn(2).setResizable(false);
            GestorGraduacion.getColumnModel().getColumn(2).setPreferredWidth(200);
            GestorGraduacion.getColumnModel().getColumn(3).setResizable(false);
            GestorGraduacion.getColumnModel().getColumn(3).setPreferredWidth(10);
            GestorGraduacion.getColumnModel().getColumn(4).setResizable(false);
            GestorGraduacion.getColumnModel().getColumn(4).setPreferredWidth(10);
            GestorGraduacion.getColumnModel().getColumn(5).setResizable(false);
            GestorGraduacion.getColumnModel().getColumn(5).setPreferredWidth(10);
        }
        GestorGraduacion.getAccessibleContext().setAccessibleName("GestorGraduacion");
        GestorGraduacion.getAccessibleContext().setAccessibleDescription("");
        GestorGraduacion.getAccessibleContext().setAccessibleParent(Gestor);

        Gestor.addTab("GESTOR DE GRADUACIONES", jScrollPane7);

        jPanel6.setBackground(new java.awt.Color(239, 239, 246));

        lblBuscar.setFont(new java.awt.Font("Cambria", 1, 18)); // NOI18N
        lblBuscar.setForeground(new java.awt.Color(51, 51, 51));
        lblBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/search.png"))); // NOI18N
        lblBuscar.setText("BUSCAR: ");

        txtBuscar.setBackground(new java.awt.Color(102, 102, 102));
        txtBuscar.setToolTipText("Digite el numero de cedula");
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtBuscarKeyPressed(evt);
            }
        });

        btnEliminar.setText("ELIMINAR");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblBuscar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 347, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 264, Short.MAX_VALUE)
                .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblBuscar)
                    .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEliminar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jDesktopPane1.setLayer(Gestor, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(jPanel6, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jDesktopPane1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jDesktopPane1Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(Gestor, javax.swing.GroupLayout.PREFERRED_SIZE, 886, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jDesktopPane1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Gestor, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12))
        );

        Gestor.getAccessibleContext().setAccessibleName("Gestor");
        Gestor.getAccessibleContext().setAccessibleDescription("contiene las graduaciones");
        Gestor.getAccessibleContext().setAccessibleParent(Gestor);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator1)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jDesktopPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jDesktopPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jLabel11.setFont(new java.awt.Font("Cambria", 1, 48)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(51, 51, 51));
        jLabel11.setText("GESTOR DE EVENTO");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel11)
                .addGap(229, 229, 229))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(239, 239, 246));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        jPanel3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jLabel1.setFont(new java.awt.Font("Batang", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 153, 255));
        jLabel1.setText("EVENTOS SOFTSI ");

        jLabel4.setFont(new java.awt.Font("sansserif", 0, 10)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 51, 51));
        jLabel4.setText("ORGANIZACION DE EVENTOS SOCIALES");

        jLabel10.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(51, 51, 51));
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/user.png"))); // NOI18N
        jLabel10.setText("MI CUENTA");
        jLabel10.setToolTipText("");
        jLabel10.setMaximumSize(new java.awt.Dimension(48, 48));
        jLabel10.setMinimumSize(new java.awt.Dimension(48, 48));
        jLabel10.setPreferredSize(new java.awt.Dimension(48, 48));

        jLabel19.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(51, 51, 51));
        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/menu.png"))); // NOI18N
        jLabel19.setText("MENU");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel19)
                .addGap(18, 18, 18)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel19)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel1.getAccessibleContext().setAccessibleName("PanelGeneral");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtBuscarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyPressed
        DefaultTableModel modelo1 = (DefaultTableModel) GestorBodas.getModel();
        String[] titulos = {"cedula,horario,lugar,fotografia,cathering,decoracion"};
        String[] registros = new String[200];
        //indicamos la base de datos 
        String sql1 = "SELECT * FROM evento WHERE cedula LIKE '%" + txtBuscar.getText() + "%'";          
        modelo1 = new DefaultTableModel(null, titulos);
        Connection cone1 = getConnection();
        try {
            st = (Statement) cone1.createStatement();
            rs = st.executeQuery(sql1);
                while (rs.next()) {
                    registros[0] = rs.getString("cedula");
                    registros[1] = rs.getString("horario");
                    registros[2] = rs.getString("lugar");                   
                    registros[3] = rs.getString("fotografia");
                    registros[4] = rs.getString("cathering");
                    registros[5] = rs.getString("decoracion");
                    modelo1.addRow(registros);
                }
                //carga en la tabla
                GestorBodas.setModel(modelo1);
            }catch (SQLException ex) {
                System.out.println("ERROR AL BUSCAR LOS DATOS : " + ex.getMessage());
            }
        DefaultTableModel modelo2 = (DefaultTableModel) GestorCumpleaños.getModel();          
            //indicamos la base de datos 
            String sql2 = "SELECT * FROM evento WHERE cedula LIKE '%" + txtBuscar.getText() + "%'";          
            modelo2 = new DefaultTableModel(null, titulos);
            Connection cone2 = getConnection();
            try {
                st = (Statement) cone2.createStatement();
                rs = st.executeQuery(sql2);
                while (rs.next()) {
                    registros[0] = rs.getString("cedula");
                    registros[1] = rs.getString("horario");
                    registros[2] = rs.getString("lugar");                   
                    registros[3] = rs.getString("fotografia");
                    registros[4] = rs.getString("cathering");
                    registros[5] = rs.getString("decoracion");
                    modelo2.addRow(registros);
                }
                //carga en la tabla
                GestorCumpleaños.setModel(modelo2);
            }catch (SQLException ex) {
                System.out.println("ERROR AL BUSCAR LOS DATOS : " + ex.getMessage());
            }
        DefaultTableModel modelo3 = (DefaultTableModel) GestorGraduacion.getModel();            
            //indicamos la base de datos 
            String sql3 = "SELECT * FROM evento WHERE cedula LIKE '%" + txtBuscar.getText() + "%'";          
            modelo3 = new DefaultTableModel(null, titulos);
            // conectamos a la base de datos 
            Connection cone3 = getConnection();
            try {
                st = (Statement) cone3.createStatement();
                rs = st.executeQuery(sql3);
                while (rs.next()) {
                    registros[0] = rs.getString("cedula");
                    registros[1] = rs.getString("horario");
                    registros[2] = rs.getString("lugar");                   
                    registros[3] = rs.getString("fotografia");
                    registros[4] = rs.getString("cathering");
                    registros[5] = rs.getString("decoracion");
                    modelo3.addRow(registros);
                }
                //carga en la tabla
                GestorGraduacion.setModel(modelo3);
            } catch (SQLException ex) {
                System.out.println("ERROR AL BUSCAR LOS DATOS : " + ex.getMessage());
            }
            if (txtBuscar.getText().length() >= 10) {  
              evt.consume();
              Toolkit.getDefaultToolkit().beep();  
        }      
    }//GEN-LAST:event_txtBuscarKeyPressed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        DefaultTableModel modelo1 = (DefaultTableModel) GestorBodas.getModel();
        try{
           //conexion que nos permite ingresar a la base se datos 
          Connection cone = getConnection();
           int fila = GestorBodas.getSelectedRow();//seleciona fila
           String cedula = GestorBodas.getValueAt(fila, 0).toString();
           //se indica en la base de datos el metodo para eliminar datos
           ps = cone.prepareStatement("  DELETE FROM evento WHERE cedula=?");
           ps.setString(1, cedula);
           ps.execute();
           //remueve la fila
           modelo1.removeRow(fila);
           //mensaje para confirmar el proceso
           JOptionPane.showMessageDialog(this,"DATO ELIMINADO CORRECTAMENTE", "INFORMACION", JOptionPane.INFORMATION_MESSAGE);

        }catch(SQLException ex){
             System.out.println("ERROR AL ELIMINAR LOS DATOS : " + ex.getMessage());
        }
        DefaultTableModel modelo2 = (DefaultTableModel) GestorCumpleaños.getModel();
        try{
           //conexion que nos permite ingresar a la base se datos 
          Connection cone = getConnection();
           int fila = GestorCumpleaños.getSelectedRow();//seleciona fila
           String cedula = GestorCumpleaños.getValueAt(fila, 0).toString();
           //se indica en la base de datos el metodo para eliminar datos
           ps = cone.prepareStatement("  DELETE FROM evento WHERE cedula=?");
           ps.setString(1, cedula);
           ps.execute();
           //remueve la fila
           modelo2.removeRow(fila);
           //mensaje para confirmar el proceso
           JOptionPane.showMessageDialog(this,"DATO ELIMINADO CORRECTAMENTE", "INFORMACION", JOptionPane.INFORMATION_MESSAGE);

        }catch(SQLException ex){
             System.out.println("ERROR AL ELIMINAR LOS DATOS : " + ex.getMessage());
        }
        DefaultTableModel modelo3 = (DefaultTableModel) GestorGraduacion.getModel();
        try{
           //conexion que nos permite ingresar a la base se datos 
          Connection cone = getConnection();
           int fila = GestorGraduacion.getSelectedRow();//seleciona fila
           String cedula = GestorGraduacion.getValueAt(fila, 0).toString();
           //se indica en la base de datos el metodo para eliminar datos
           ps = cone.prepareStatement("  DELETE FROM evento WHERE cedula=?");
           ps.setString(1, cedula);
           ps.execute();
           //remueve la fila
           modelo3.removeRow(fila);
           //mensaje para confirmar el proceso
           JOptionPane.showMessageDialog(this,"DATO ELIMINADO CORRECTAMENTE", "INFORMACION", JOptionPane.INFORMATION_MESSAGE);
        }catch(SQLException ex){
             System.out.println("ERROR AL ELIMINAR LOS DATOS : " + ex.getMessage());
        }
    }//GEN-LAST:event_btnEliminarActionPerformed
                                                                                 
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Gestor_eventos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Gestor_eventos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Gestor_eventos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Gestor_eventos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Gestor_eventos().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTabbedPane Gestor;
    private javax.swing.JTable GestorBodas;
    private javax.swing.JTable GestorCumpleaños;
    private javax.swing.JTable GestorGraduacion;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblBuscar;
    private javax.swing.JTextField txtBuscar;
    // End of variables declaration//GEN-END:variables
}
